# Fleet Fuel Efficiency and Maintenance Decision Support

Mini project: cleans messy fleet data (duplicate fuel entries, mixed units, bad odometer
readings), combines trips + fuel + maintenance, calculates efficiency and cost measures,
stores everything in SQLite and shows a Streamlit dashboard.

## Folder layout
```
fleet_project/
  generate_data.py     step 1: makes mock CSVs in data/
  clean.py             step 2: cleans, combines, calculates, saves fleet.db + output/
  app.py               step 3: Streamlit dashboard
  requirements.txt
  data/                raw CSVs (vehicles, trips, fuel, maintenance)       <- created by step 1
  output/              cleaned_trips.csv, cleaned_fuel.csv, vehicle_comparison.csv,
                       needs_verification.csv, report.md                   <- created by step 2
  fleet.db             SQLite database                                     <- created by step 2
```

## How to run
1. Install Python 3.10+ from python.org (tick "Add Python to PATH" on Windows).
2. Put the 3 .py files and requirements.txt in one folder called `fleet_project`.
3. Open that folder in VS Code (File > Open Folder), then open the terminal (Ctrl + `).
4. (Recommended) create a virtual environment:
   - Windows:   `python -m venv venv`  then  `venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv venv`  then  `source venv/bin/activate`
5. `pip install -r requirements.txt`
6. `python generate_data.py`
7. `python clean.py`
8. `streamlit run app.py`  (opens http://localhost:8501)

Steps 6 and 7 only need to be repeated if you change the data or the cleaning rules.

## How the cleaning works
| Problem | Fix |
|---|---|
| Duplicate fuel entries | same vehicle + date + litres + cost, keep first, log the rest |
| Gallons / miles | converted to litres / km |
| Messy vehicle IDs (`v03`, ` V03`) | trimmed and upper-cased |
| Odometer goes backwards | trip flagged, excluded |
| Odometer jumps > 100 km between trips | trip flagged, excluded |
| Distance differs from odometer by > 5% | trip flagged, excluded |
| Fill-up above tank size / price outside Rs 60-140 per litre | fuel row flagged, excluded |

Thresholds are constants at the top of `clean.py`.

## Measures
- Fuel efficiency (km/L) = valid km / valid litres
- Cost per km = (fuel cost + maintenance cost) / valid km, also split into fuel and maintenance
- % records flagged = flagged (trip + fuel, incl. duplicates) / all trip + fuel records

## Example SQL (also in the dashboard's SQL tab)
```sql
SELECT vehicle_id, model, ROUND(total_cost_per_km, 2) AS cost_per_km
FROM vehicle_summary ORDER BY cost_per_km DESC;
```

## Using your own data
Replace the CSVs in `data/` keeping the same column names, skip step 6, run steps 7 and 8.
